Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
===== RESTART: C:\Users\dell\AppData\Local\Programs\Python\Python312\ab4.py ====
20
name:akki
rollno:101
marks:76 95 87 94
name:veve
rollno:102
marks:47 58 36 27
name:nayh
rollno:103
marks:38 57 93 38
name:nans
rollno:104
marks:48 56 37 28
name:gumi
rollno:105
marks:38 57 47 83
name:naga
rollno:106
marks:38 46 27 38
name:nana
rollno:107
marks:48 36 28 49
name:anil
rollno:108
marks:38 57 47 58
name:amma
rollno:109
marks:39 57 38 29
name:anju
rollno:110
marks:39 67 46 52
name:nagi
rollno:111
marks:38 56 47 38
name:ravi
rollno:112
marks:28 47 68 61
name:raju
rollno:113
marks:29 67 84 56
name:samee
rollno:114
marks:38 57 49 37
name:keer
rollno:115
marks:38 57 47 67
name:bala
rollno:116
marks:48 57 68 39
name:abhi
rollno:117
marks:85 64 37 48
name:aksa
rollno:118
marks:48 57 64 36
name:renu
rollno:119
marks:39 47 56 38
name:pooj
rollno:120
marks:38 57 38 57
     name rollno             marks  total
0    akki    101  [76, 95, 87, 94]    352
1    veve    102  [47, 58, 36, 27]    168
2    nayh    103  [38, 57, 93, 38]    226
3    nans    104  [48, 56, 37, 28]    169
4    gumi    105  [38, 57, 47, 83]    225
5    naga    106  [38, 46, 27, 38]    149
6    nana    107  [48, 36, 28, 49]    161
7    anil    108  [38, 57, 47, 58]    200
8    amma    109  [39, 57, 38, 29]    163
9    anju    110  [39, 67, 46, 52]    204
10   nagi    111  [38, 56, 47, 38]    179
11   ravi    112  [28, 47, 68, 61]    204
12   raju    113  [29, 67, 84, 56]    236
13  samee    114  [38, 57, 49, 37]    181
14   keer    115  [38, 57, 47, 67]    209
15   bala    116  [48, 57, 68, 39]    212
16   abhi    117  [85, 64, 37, 48]    234
17   aksa    118  [48, 57, 64, 36]    205
18   renu    119  [39, 47, 56, 38]    180
19   pooj    120  [38, 57, 38, 57]    190
no of students: 20
first:352 name: akki rollno: 101 marks: [76, 95, 87, 94]
last:149 name: naga rollno: 106 marks: [38, 46, 27, 38]
sorted in choosed subj: [28, 29, 38, 38, 38, 38, 38, 38, 38, 38, 39, 39, 39, 47, 48, 48, 48, 48, 76, 85]
subject wise high marks:
ak 1 : 85
ak 2 : 95
ak 3 : 93
ak 4 : 94
veve
veve 102 [47, 58, 36, 27] 168
sort_total_marks:
149
161
163
168
169
179
180
181
190
200
204
204
205
209
212
225
226
234
236
352
