import pandas as pd
s=[]
l=[]
def akki(name,rollno,marks):
    stu={
       'name':name,
       'rollno':rollno,
       'marks':marks,
       'total':total
       }
    s.append(stu)
n=int(input())
for i in range(n):
    name=input('name:')
    rollno=input('rollno:')
    marks=list(map(int,input('marks:').split()))
    total=sum(marks)
    akki(name,rollno,marks)
#print('name\t\trollno\t\tmarks\t\ttotal')
#for i in range(n):
 #   print(s[i]['name']+'\t\t'+str(s[i]['rollno'])+'\t\t'+str(s[i]['marks'])+'\t'+str(s[i]['total']))
df=pd.DataFrame(s)
print(df)
m=df['total'].max()
mn=df['total'].min()
print('no of students:',len(s))
high_mar=max(s,key=lambda x:x['total'])
print(f'first:{m}','name:',high_mar['name'],'rollno:',high_mar['rollno'],'marks:',high_mar['marks'])
low_mar=min(s,key=lambda x:x['total'])
print(f'last:{mn}','name:',low_mar['name'],'rollno:',low_mar['rollno'],'marks:',low_mar['marks'])
for i in range(n):
    l.append(s[i]['marks'][0])
    l.sort()
print('sorted in choosed subj:',l)
sub_high={}
for ak in s:
    for aki,akm in enumerate(ak['marks']):
        if aki not in sub_high or akm >sub_high[aki]:
            sub_high[aki]=akm
print('subject wise high marks:')
for aki,big_marks in sub_high.items():
    print('ak',aki+1,':',big_marks)
clg=input()
for i in range(n):
    if(s[i]['name'])==clg:
        print(s[i]['name'],s[i]['rollno'],s[i]['marks'],s[i]['total'])
sort_total_marks=sorted(s,key=lambda x:x['total'])
print('sort_total_marks:')
for s in sort_total_marks:
    print(s['total'])

